# include<iostream>
# include<stdio.h>
# include<string.h>
#include <chrono>
#include <unistd.h>
#include<algorithm>
using namespace std;
const long SIZE=1048578;
int ar[SIZE];
void swap(int *a,int  *b){
	int t=*a;
	*a=*b;
	*b=t;
}

// Merge two subarrays L and M into arr
void merge( int p, int q, int r) {

    // Create L ← A[p..q] and M ← A[q+1..r]
    int n1 = q - p + 1;
    int n2 = r - q;

    int L[n1], M[n2];

    for (int i = 0; i < n1; i++)
        L[i] = ar[p + i];
    for (int j = 0; j < n2; j++)
        M[j] = ar[q + 1 + j];

    // Maintain current index of sub-arrays and main array
    int i, j, k;
    i = 0;
    j = 0;
    k = p;

    // Until we reach either end of either L or M, pick larger among
    // elements L and M and place them in the correct position at A[p..r]
    while (i < n1 && j < n2) {
        if (L[i] <= M[j]) {
            ar[k] = L[i];
            i++;
        } else {
            ar[k] = M[j];
            j++;
        }
        k++;
    }

    // When we run out of elements in either L or M,
    // pick up the remaining elements and put in A[p..r]
    while (i < n1) {
        ar[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        ar[k] = M[j];
        j++;
        k++;
    }
}
void mergeSort(int start,int last,int n){
	if (start < last) 
    {int mid = (start+last)/2;
        mergeSort( start, mid,n);
        mergeSort(mid+1, last , n);
        merge( start,mid,last);}
}

void print(int size){
	//cout<<size<<endl;
	for(int i=0;i<size;i++){
		cout<<ar[i]<<" ";
	}
}

int read(int i){
	FILE *filepointer;
	
	string filename="";int c;
	filename+="File ";
	filename+='0'+i;
	filename+=".txt";
	const char *cc = filename.c_str();
	//cout<<filename;
	filepointer=fopen(cc,"r");
	if(filepointer==NULL){
		cout<<"Cannot open file"<<endl;
	}
	else{
		int i=0;
    	while (!feof (filepointer)){
    		fscanf (filepointer, "%d", &c);
        	//printf ("%d ", c);
        	ar[i]=c;
        	i++;
        	//cout<<i<<endl;
    	}
    	//cout<<23<<endl;
    	fclose(filepointer);
    	return i;
	}
	return 0;
}
int main(){
	cout<<"Merge Sort of 2 division "<<endl;
	cout<<"Average Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);
		//cout<<size<<endl;
		//print(size);
		auto start = chrono::steady_clock::now();
		mergeSort(0,size-1,size);
		//print(size);
		//cout<<size<<endl;
		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " µs" << endl;
		//print(size);	cout<<endl;
	}
	cout<<"Best Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);
		sort(ar,ar+size);
		auto start = chrono::steady_clock::now();
		mergeSort(0,size-1,size);

		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " µs" << endl;
		//print(size);	cout<<endl;
	}

	cout<<"Worst Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);
		sort(ar,ar+size);
		reverse(ar,ar+size);
		//print(size);
		auto start = chrono::steady_clock::now();
		mergeSort(0,size-1,size);

		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " µs" << endl;
			//cout<<endl;
	}
	return 0;
}