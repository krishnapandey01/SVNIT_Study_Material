# include<iostream>
# include<stdio.h>
# include<string.h>
#include <chrono>
#include <unistd.h>
#include<algorithm>
using namespace std;
const long SIZE=1048578;
int ar[SIZE];
void swap(int *a,int  *b){
	int t=*a;
	*a=*b;
	*b=t;
}

void insertionSort(int size) {
   int key, j;
   for(int i = 1; i<size; i++) {
      key = ar[i];
      j = i;
      while(j > 0 && ar[j-1]>key) {
         ar[j] = ar[j-1];
         j--;
      }
      ar[j] = key;   //insert in right place
   }
}
void print(int size){
	for(int i=0;i<size;i++){
		cout<<ar[i]<<" ";
	}
}

int read(int i){
	FILE *filepointer;

	string filename="";int c;
	filename+="File ";
	filename+='0'+i;
	filename+=".txt";
	const char *cc = filename.c_str();

	filepointer=fopen(cc,"r");
	if(filepointer==NULL){
		cout<<"Cannot open file"<<endl;
	}
	else{
		int i=0;
    	while (!feof (filepointer)){
    		fscanf (filepointer, "%d", &c);
        	//printf ("%d", c);
        	ar[i]=c;
        	i++;
    	}
    	fclose(filepointer);
    	return i;
	}
	return 0;
}
int main(){
	cout<<"Insertion Sort "<<endl;
	cout<<"Average Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);

		auto start = chrono::steady_clock::now();
		insertionSort(size);

		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " �s" << endl;
		//print(size);	cout<<endl;
	}
	cout<<"Best Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);
		sort(ar,ar+size);
		auto start = chrono::steady_clock::now();
		insertionSort(size);

		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " �s" << endl;
		//print(size);	cout<<endl;
	}

	cout<<"worst Case"<<endl;
	for(int i=0;i<5;i++){
		int size=read(i+1);
		sort(ar,ar+size);
		reverse(ar,ar+size);
		//print(size);
		auto start = chrono::steady_clock::now();
		insertionSort(size);

		auto end = chrono::steady_clock::now();

		cout << "Elapsed time in microseconds for "<<i+1<<"th file :"
        << chrono::duration_cast<chrono::microseconds>(end - start).count()
        << " �s" << endl;
			//cout<<endl;
	}
	return 0;
}
